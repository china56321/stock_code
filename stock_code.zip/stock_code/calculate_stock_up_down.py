#!/usr/bin/python
# -*- coding: UTF-8 -*- 
import pandas as pd
import os
import numpy as np   
import matplotlib.pyplot as plt 

mean_5_10_20_names = os.listdir('./mean_5_10_20/')

up_num=0
down_num=0
for mean_5_10_20_name in mean_5_10_20_names :
    df = pd.read_excel('./mean_5_10_20/' + mean_5_10_20_name,sheet_name=0)

    if mean_5_10_20_name.split(".")[0][:3]=="688":
        continue
    elif len(df['open'])<120:
        continue
    stock_close=df['close']
    stock_open=df['open']

    if stock_close[0]>=stock_open[0]:
       up_num+=1
       print("The number of stock_top is :--->",up_num)
       print("top_name:",mean_5_10_20_name)
    else:
       down_num+=1
       print("The number of stock_down is :--->",down_num)
       print("down_name:",mean_5_10_20_name)

print('*'*50)
print("The total number of stock_top is :--->",up_num)
print("The total number of stock_down is :--->",down_num)
print('*'*50)







