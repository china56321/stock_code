import time
import os
import shutil
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import tushare as ts

ts.set_token('53f7543547a1c56ac53a0aa58521ed9e2de575e8cca53cbd85775fc6')

pro = ts.pro_api()


# 若存在balancesheet文件，则删除;不存在，则生成
if os.path.exists("balancesheet"):
    shutil.rmtree("balancesheet")  # delete balancesheet folder
os.makedirs("balancesheet")        # make new balancesheet folder

date=time.strftime("%Y%m%d")

df = pd.read_excel('day_stock.xlsx')
stock_codes=df['ts_code']
i=1
for stock_code in stock_codes:
  if i%50==0:
     time.sleep(61)
     print("time sleep:",i)
     i+=1
  else :
     df = pro.balancesheet(ts_code=stock_code, start_date='20180101', end_date=date, fields='ts_code,ann_date,f_ann_date,end_date,report_type,comp_type,cap_rese')   
     df.to_excel('./balancesheet/'+ stock_code +'.xlsx','encoding=utf-8')
     i+=1
     print("downloading processing===>",i)


