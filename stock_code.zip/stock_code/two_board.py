#!/usr/bin/python
# -*- coding: UTF-8 -*- 
import pandas as pd
import os
import numpy as np   
import matplotlib.pyplot as plt 


f = open("two_board.csv" , "w")
f.truncate()
f.close

mean_5_10_20_names = os.listdir('./mean_5_10_20/')
j=0
for mean_5_10_20_name in mean_5_10_20_names :
    df = pd.read_excel('./mean_5_10_20/' + mean_5_10_20_name,sheet_name=0)

    if mean_5_10_20_name.split(".")[0][:3]=="688":
        continue
    elif len(df['open'])<120:
        continue

    pct_chg=df['pct_chg']
    if (9.9<=pct_chg[0]<=10.5 and 9.9<=pct_chg[1]<=10.5) or (19<=pct_chg[0]<=20.5 and 19.9<=pct_chg[1]<=20.5)  :
        with open("two_board.csv",'a') as f:
           f.write(mean_5_10_20_name.split('.')[0]+'.'+ mean_5_10_20_name.split('.')[1].lower()+'   ')
           f.write('\n')
           j+=1
           print("The number of stock be choosen===>",j)




























