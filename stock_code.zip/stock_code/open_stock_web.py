#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os
import sys
import termios

import webbrowser
url_head='http://quote.eastmoney.com/'                    

# 此函数用来控制暂停打开股票页面
def press_any_key_exit(msg):
  # 获取标准输入的描述符
  fd = sys.stdin.fileno()

  # 获取标准输入(终端)的设置
  old_ttyinfo = termios.tcgetattr(fd)

  # 配置终端
  new_ttyinfo = old_ttyinfo[:]

  # 使用非规范模式(索引3是c_lflag 也就是本地模式)
  new_ttyinfo[3] &= ~termios.ICANON
  # 关闭回显(输入不会被显示)
  new_ttyinfo[3] &= ~termios.ECHO

  # 输出信息
  sys.stdout.write(msg)
  sys.stdout.flush()
  # 使设置生效
  termios.tcsetattr(fd, termios.TCSANOW, new_ttyinfo)
  # 从终端读取
  os.read(fd, 7)

  # 还原终端设置
  termios.tcsetattr(fd, termios.TCSANOW, old_ttyinfo)
  
# 打开所有选择的股票页面
with open('choosen_stock.csv') as f:
  stock_lines=f.readlines()
  for stock_line in stock_lines:
    stock_code=stock_line.split('.')[0]
    stock_sz_sh=stock_line.split('.')[1].split(' ')[0]
    webbrowser.open_new_tab(url_head+stock_sz_sh+stock_code+'.html') 
    print(url_head+'/'+stock_sz_sh+stock_code+'.html')
    press_any_key_exit('按任一键继续...')








