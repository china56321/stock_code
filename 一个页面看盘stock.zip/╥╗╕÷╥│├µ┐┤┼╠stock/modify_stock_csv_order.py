
f = open("a.csv" , "w")
f.truncate()
f.close

with open("stock1.csv",'r') as f :
    a=f.readlines()
    for i in a :
      # print(i.split('.')[-1] )
      j=i.split('.')[-1].strip() + i.split('.')[0]
      # print(j)
      with open("a.csv",'a') as k:
          k.write(j)
          k.write('\n') 